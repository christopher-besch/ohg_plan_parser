# ToDo
- [ ] Change `function` to `update` Change instance with data from the "Vertretungsplan"
- [ ] `index` page
- [ ] better `faulty` url page
- [x] url in `GitHub`
- [ ] `help` in settings / tutorial
- [ ] better `address`
- [ ] `SSL`
- [x] week start date option
