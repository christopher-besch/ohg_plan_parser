# ohg_plan_parser
A very simple python 3 parser for the representation plan of the Otto-Hahn-Gymnasium in Gifhorn/Germany

Still in alpha state
